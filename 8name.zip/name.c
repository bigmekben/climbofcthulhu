#include <allegro.h>
#include <stdio.h>
#include <string.h>


char chr_file[PATH_MAX], pal_file[PATH_MAX], nam_file[PATH_MAX];


unsigned char nametable[32][32], chr[256][2][8];
unsigned char pal[16] =
{
  0x0f,0x00,0x10,0x30,
  0x0f,0x06,0x16,0x26,
  0x0f,0x0a,0x1a,0x2a,
  0x0f,0x02,0x12,0x22
};


/*
This NES palette was created with nestopia's ntsc filter
*/

static const unsigned int nesPalette[64] = {
0x666666,
0x002a88,
0x1412a7,
0x3b00a4,
0x5c007e,
0x6e0040,
0x6c0600,
0x561d00,
0x333500,
0x0b4800,
0x005200,
0x004f08,
0x00404d,
0,
0,
0,
0xadadad,
0x155fd9,
0x4240ff,
0x7527fe,
0xa01acc,
0xb71e7b,
0xb53120,
0x994e00,
0x6b6d00,
0x388700,
0x0c9300,
0x008f32,
0x007c8d,
0,
0,
0,
0xffffff,
0x64b0ff,
0x9290ff,
0xc676ff,
0xf36aff,
0xfe6ecc,
0xfe8170,
0xea9322,
0xbcbe00,
0x88d800,
0x5ce430,
0x45e082,
0x48cdde,
0x4f4f4f,
0,
0,
0xffffff,
0xc0dfff,
0xd3d2ff,
0xe8c8ff,
0xfbc2ff,
0xfec4ea,
0xfeccc5,
0xf7d8a5,
0xe4e594,
0xcfef96,
0xb4dfab,
0xb3f3cc,
0xb5efb2,
0xb8b8b8,
0,
0
};

/* where the NES palette starts in the PC palette */
#define PALBASE 64

unsigned int cur_tile = 'A', cur_attr = 0;


/* draw_big_tile() *********************
   Draws a CHR tile at 16x16 (that is, scaled up by 2).
*/
void draw_big_tile(unsigned int x, unsigned int y,
                   unsigned int tileno, unsigned int attr)
{
  unsigned int inx, iny;

  /* use range 16-31 so as not to interfere with standard colors */
  attr = ((attr & 0x03) << 2) + PALBASE;

  for(iny = 0; iny < 16; iny++)
  {
    unsigned int b0 = chr[tileno][0][iny >> 1];
    unsigned int b1 = chr[tileno][1][iny >> 1];

    for(inx = 0; inx < 16; inx += 2)
    {
      unsigned int c = attr | ((b0 & 0x80) >> 7) | ((b1 & 0x80) >> 6);
      putpixel(screen, x + inx, y + iny, c);
      putpixel(screen, x + inx + 1, y + iny, c);
      b0 <<= 1;
      b1 <<= 1;
    }
  }
}


/* draw_little_tile() ******************
   Draws a tile at 8x8.
*/
void draw_little_tile(unsigned int x, unsigned int y,
                      unsigned int tileno, unsigned int attr)
{
  unsigned int inx, iny;

  attr = ((attr & 0x03) << 2) + PALBASE;

  for(iny = 0; iny < 8; iny++)
  {
    unsigned int b0 = chr[tileno][0][iny];
    unsigned int b1 = chr[tileno][1][iny];

    for(inx = 0; inx < 8; inx++)
    {
      unsigned int c = attr | ((b0 & 0x80) >> 7) | ((b1 & 0x80) >> 6);
      putpixel(screen, x + inx, y + iny, c);
      b0 <<= 1;
      b1 <<= 1;
    }
  }
}


/* get_attr() **************************
   Returns the attribute at (x, y).
*/
unsigned int get_attr(unsigned int x, unsigned int y)
{
  unsigned int attr = nametable[30][(y >> 2) * 8 + (x >> 2)];

  if(y & 2)
    attr >>= 4;
  if(x & 2)
    attr >>= 2;
  return attr & 0x03;
}


/* put_attr() **************************
   Sets the attribute at (x, y).
*/
void put_attr(unsigned int x, unsigned int y, unsigned int attr)
{
  unsigned int attrbyte, attrmask = 0x03;

  if(x >= 32 || y >= 30)
  {
    char line2[64];

    usprintf(line2, "at (%d, %d)", x, y);
    alert("tried to write outside of attr",
          line2,
          "but at least you're not r00ted",
          "OK", 0, 13, 0);
    return;
  }

  attr &= 0x03;
  attr |= attr << 2;
  attr |= attr << 4;
  if(y & 2)
    attrmask <<= 4;
  if(x & 2)
    attrmask <<= 2;

  attrbyte = nametable[30][(y >> 2) * 8 + (x >> 2)];
  attrbyte = (attrbyte & ~attrmask) | (attr & attrmask);
  nametable[30][(y >> 2) * 8 + (x >> 2)] = attrbyte;
}


/* draw_nt_tile() **********************
   Draws the tile at position (x, y) of the nametable.
*/
void draw_nt_tile(unsigned int x, unsigned int y)
{
  draw_big_tile(x << 4, y << 4, nametable[y][x], get_attr(x, y)); 
}


/* draw_attr() *************************
   Draws the tiles sharing an attribute with position (x, y)
   of the nametable.
*/
void draw_attr(unsigned int x, unsigned int y)
{
  unsigned int ex, wy;

  x &= 0x1e;
  y &= 0x1e;

  acquire_screen();
  for(wy = 0; wy < 2; wy++)
    for(ex = 0; ex < 2; ex++)
      draw_nt_tile(x + ex, y + wy);
  release_screen();
}


/* draw_tilepal() **********************
   Draws the tile palette with the specified attribute.
*/
void draw_tilepal(unsigned int attr)
{
  unsigned int t = 0;
  unsigned int x, y;

  for(y = 64; y < 192; y += 8)
    for(x = 512; x < 640; x += 8)
      draw_little_tile(x, y, t++, attr);
}


/* draw_colorpal() *********************
   Draws the color palette with the specified attribute.
*/
void draw_colorpal(void)
{
  const int ybase = 208;
  unsigned int i;

  acquire_screen();
  rectfill(screen, 512, ybase, 639, ybase + 31, PALBASE);
  for(i = 0; i < 4; i++)
  {
    unsigned int xbase = i * 32 + 512;

    rectfill(screen, xbase + 16, ybase + 2, xbase + 29, ybase + 15, i * 4 + PALBASE + 1);
    rectfill(screen, xbase + 2, ybase + 16, xbase + 15, ybase + 29, i * 4 + PALBASE + 2);
    rectfill(screen, xbase + 16, ybase + 16, xbase + 29, ybase + 29, i * 4 + PALBASE + 3);
    if(i == cur_attr)
    {
      rect(screen, xbase, ybase, xbase + 31, ybase + 31, 31);
      rect(screen, xbase + 1, ybase + 1, xbase + 30, ybase + 30, 16);
    }
  }
  release_screen();
}

/* draw_sample() ***********************
   Draws the sample of the selection.
*/
void draw_sample(void)
{
  unsigned int x, y;

  acquire_screen();
  textprintf_ex(screen, font, 552, 256, 31, 16, "T%02x A%1x", cur_tile, cur_attr);

  for(y = 264; y < 312; y += 16)
    for(x = 544; x < 608; x += 16)
      draw_big_tile(x, y, cur_tile, cur_attr);
  release_screen();
}


/* draw_sidebar() **********************
   Draws the entire sidebar.
*/
void draw_sidebar(void)
{
  unsigned int i;

  acquire_screen();
  rectfill(screen, 512, 0, 639, 63, 24);
  rectfill(screen, 512, 200, 639, 207, 24);
  rectfill(screen, 512, 248, 639, 255, 24);
  rectfill(screen, 512, 256, 543, 319, 24);
  rectfill(screen, 608, 256, 639, 319, 24);
  rectfill(screen, 512, 320, 639, 479, 24);
  for(i = 0; i < 8; i++)
  {
    hline(screen, 512, i + 192, 639, i + 16);
    hline(screen, 512, i + 240, 639, i + 16);
    hline(screen, 544, i + 312, 607, i + 16);
  }

  draw_tilepal(cur_attr);
  draw_colorpal();
  draw_sample();
  release_screen();

}


void draw_whole_screen(void)
{
  unsigned int x, y;

  acquire_screen();
  scare_mouse();
  for(y = 0; y < 30; y++)
    for(x = 0; x < 32; x++)
      draw_nt_tile(x, y);
  unscare_mouse();
  release_screen();

  draw_sidebar();
}

void set_nes_pal(void)
{
  unsigned int x;

  for(x = 0; x < 16; x++)
  {
    unsigned int palsrc = ((x & 3) ? x : 0);
    int c = nesPalette[pal[palsrc] & 0x3F];
    
    RGB s = {(c >> 18) & 0x3F,
             (c >> 10) & 0x3F,
             (c >> 2) & 0x3F};

    set_color(x + PALBASE, &s);
  }
}


int fileread(void *buf, size_t size, const char *filename, int complain)
{
  FILE *fp = fopen(filename, "rb");

  if(!fp)
  {
    if(complain)
      allegro_message("could not read %s: %s\n", filename, strerror(errno));
    return 1;
  }
  if(fread(buf, 1, size, fp) < size)
  {
    if(complain)
      allegro_message("could not read %lu from %s: %s\n",
                      (unsigned long)size, filename, strerror(errno));
    fclose(fp);
    return 1;
  }
  fclose(fp);
  return 0;
}


int filewrite(void *buf, size_t size, const char *filename, int complain)
{
  FILE *fp = fopen(filename, "wb");

  if(!fp)
  {
    if(complain)
      alert("could not write to", filename, strerror(errno),
            "OK", 0, 13, 0);
    return 1;
  }
  if(fwrite(buf, 1, size, fp) < size)
  {
    if(complain)
      alert("could not write all of", filename, strerror(errno),
            "OK", 0, 13, 0);
    fclose(fp);
    return 1;
  }
  fclose(fp);
  if(complain)
    alert(filename, "saved.", "", "OK", 0, 13, 0);
  return 0;
}


void left_click(int x, int y)
{
  if(x < 512)
  {
    x >>= 4;
    y >>= 4;
    while(mouse_b & 1)
    {
      if(x >= 0 && x < 32 && y >= 0 && y < 30)
      {
        nametable[y][x] = cur_tile;
        put_attr(x, y, cur_attr);
        scare_mouse();
        draw_attr(x, y);
        unscare_mouse();
      }
      rest(0);
      vsync();
      x = mouse_x >> 4;
      y = mouse_y >> 4;
    }
    return;
  }

  /* convert sidebar coords to a 16x60 field */
  x = (x - 512) >> 3;
  y >>= 3;

  if(y >= 8 && y < 24)
  {
    cur_tile = (y - 8) * 16 + x;
    draw_sample();
    return;
  }

  if(y >= 26 && y < 30)
  {
    cur_attr = x >> 2;
    acquire_screen();
    scare_mouse();
    draw_colorpal();
    draw_sample();
    draw_tilepal(cur_attr);
    unscare_mouse();
    release_screen();
    return;
  }
}


void right_click(int x, int y)
{
  if(x < 512)
  {
    x >>= 4;
    y >>= 4;
    while(mouse_b & 2)
    {
      if(x >= 0 && x < 32 && y >= 0 && y < 30)
      {
        int last_attr = cur_attr;
        int last_tile = cur_tile;

        cur_tile = nametable[y][x];
        cur_attr = get_attr(x, y);

        acquire_screen();
        scare_mouse();
        if(cur_attr != last_attr)
        {
          draw_colorpal();
          draw_tilepal(cur_attr);
        }
        if(cur_tile != last_tile)
        {
          draw_sample();
        }
        unscare_mouse();
        release_screen();
      }
      rest(0);
      vsync();
      x = mouse_x >> 4;
      y = mouse_y >> 4;
    }
    return;
  }

  /* convert sidebar coords to a 16x60 field */
  x = (x - 512) >> 3;
  y >>= 3;

  if(y >= 8 && y < 24)
  {
    cur_tile = (y - 8) * 16 + x;
    draw_sample();
    return;
  }

#if 0
  if(y >= 26 && y < 30)
  {
    /* open palette editor */
  }
#endif
}


void typing_keypress(unsigned int x, unsigned int y, unsigned int c)
{
  if(x < 512)
  {
    scare_mouse();
    position_mouse(x + 16, y);
    x >>= 4;
    y >>= 4;
    nametable[y][x] = c;
    draw_attr(x, y);
    unscare_mouse();
  }

}

void move_mouse_by_tile(signed int dx, signed int dy)
{
  int x = mouse_x, y = mouse_y;
  if(x < 512)
  {
    scare_mouse();
    position_mouse(x + 16 * dx, y + 16 * dy);
    unscare_mouse();
  }

}

const char helpText[] =
"Usage: 8name CHRFILE PALFILE NAMFILE\n"
"Usage: 8name FILENAME\n"
"       (automatically appends .chr, .pal, and .nam to FILENAME)\n"
"\n"
"Options:\n"
"  -f, --full        Force full screen, ignoring windowed mode.\n"
"  -h, -?, --help    Display this help message\n"
"  -v, --version     Display version and copyright information\n";

const char versionText[] =
"8Name 0.4\n"
"Copyright 2001-2008 Damian Yerrick\n"
"This program comes with ABSOLUTELY NO WARRANTY.  It is free software,\n"
"and you are welcome to redistribute it under certain conditions.\n"
"Please see the manual for more information.\n";

int main(int argc, char **argv)
{
  char done = 0, forceFullScreen = 0;
  int last_mouse_b = 0x07;
  int arg;

  allegro_init();

  for (arg = 1; arg < argc; ++arg) {
    if (!strcmp(argv[arg], "-h")
	    || !strcmp(argv[arg], "-?")
	    || !strcmp(argv[arg], "--help")) {
	  allegro_message(helpText);
	  return 0;
	} else if (!strcmp(argv[arg], "-v")
	           || !strcmp(argv[arg], "--version")) {
	  allegro_message(versionText);
	  return 0;
	} else if (!strcmp(argv[arg], "-f")
	           || !strcmp(argv[arg], "--full")) {
	  forceFullScreen = 1;
	} else if (chr_file[0] == 0) {
      strcpy(chr_file, argv[arg]);
    } else if (pal_file[0] == 0) {
      strcpy(pal_file, argv[arg]);
    } else if (nam_file[0] == 0) {
      strcpy(nam_file, argv[arg]);
    } else {
      allegro_message("8name: too many filenames; try 8name --help\n");
      return EXIT_FAILURE;
    }
  }
  if (!chr_file[0]) {
    allegro_message("8name: too few filenames; try 8name --help\n");
    return EXIT_FAILURE;
  }
  if (chr_file[0] && pal_file[0] && nam_file[0]) {
    // fall through
  } else if (chr_file[0] && !pal_file[0] && !nam_file[0]) {
    strcpy(pal_file, chr_file);
    strcpy(nam_file, chr_file);
    strcat(chr_file, ".chr");
    strcat(pal_file, ".pal");
    strcat(nam_file, ".nam");
  } else {
    allegro_message("8name: invalid number of filenames; try 8name --help\n");
    return EXIT_FAILURE;
  }

  if(fileread(chr, 4096, chr_file, 1))
    return 1;
  fileread(pal, 16, pal_file, 0);
  fileread(nametable, 1024, nam_file, 0);

  install_timer();
  install_keyboard();

  if((forceFullScreen
      || set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0) < 0)
     && set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0) < 0)
  {
    allegro_message("Could not open a 640x480 window\n");
    return 1;
  }
  set_nes_pal();
  install_mouse();
  show_mouse(screen);

  draw_whole_screen();
  while(!done)
  {
    unsigned int cur_mouse_b = mouse_b;
    if(cur_mouse_b & (~last_mouse_b) & 1)
    {
      left_click(mouse_x, mouse_y);
    }
    if(cur_mouse_b & (~last_mouse_b) & 2)
    {
      right_click(mouse_x, mouse_y);
    }
    last_mouse_b = cur_mouse_b;
    if(keypressed())
    {
      int scancode;
      int asck = ureadkey(&scancode);

      if(asck >= 0x20 && asck <= 0x7e)
        typing_keypress(mouse_x, mouse_y, asck);
      else switch(asck)
      {
      case 0:
        switch (scancode) {
        case KEY_UP:
          move_mouse_by_tile(0, -1);
          break;
        case KEY_DOWN:
          move_mouse_by_tile(0, 1);
          break;
        case KEY_LEFT:
          move_mouse_by_tile(-1, 0);
          break;
        case KEY_RIGHT:
          move_mouse_by_tile(1, 0);
          break;
        }
        break;

      case 'S'-'@':  /* ctrl+S */
        filewrite(nametable, 1024, nam_file, 1);
        break;

      case 27:       /* escape */
      case 'Q'-'@':
        done = 1;
        break;

      case 8:   /* backspace */
        move_mouse_by_tile(-1, 0);
        break;
      }
    }
    rest(10);
  }

  return 0;
} END_OF_MAIN();
